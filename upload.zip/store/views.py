from django.shortcuts import render,redirect
from store.forms.authforms import CustomerCreationForm,CustomerAuthForm
from django.contrib.auth.forms import AuthenticationForm
from math import floor
from django.contrib.auth import authenticate,login as loginUser,logout
from store.models import *

def show_item(request ,id):
    product = Product.objects.get(pk=id)
    size = request.GET.get('size')


    if size is None:
        size = product.sizevarient_set.all().order_by('price').first()
    else:
        size = product.sizevarient_set.get(size=size)
    size_price = floor(size.price)

    sell_price = size_price - (size_price * (product.discount / 100))
    sell_price = floor(sell_price)
    context = {'product': product , 'price ': size_price, 'sell_price': sell_price ,'active_size': size }
    return render(request,template_name='store/item_details.html',context=context)

def home(request):
    products=Product.objects.all()
    context = {
        "products" : products
    }
    return render(request,template_name='store/home.html',context=context)

def cart(request):
    return render(request,template_name='store/cart.html')

def orders(request):
    return render(request,template_name='store/orders.html')


def signup(request):
    if (request.method == 'GET'):
        form = CustomerCreationForm()
        context = {"form": form}
        return render(request,
                      template_name='store/signup.html',
                      context=context)

    else:
        form = CustomerCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.email = user.username
            user.save()
            print(user)
            return render(request,template_name='store/login.html')
        context = {"form": form}
        return render(request,
                      template_name='store/signup.html',
                      context=context)



def login(request):
    if request.method == 'GET':
        form = CustomerAuthForm
        return render(request,template_name='store/login.html',context={'form':form})
    else:
        form = CustomerAuthForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username,password=password)
            if user:
                loginUser(request,user)
                return redirect('homepage')

        else:
            return render(request, template_name='store/login.html', context={'form': form})


def signout(request):
    logout(request)
    return render(request,template_name='store/home.html')

