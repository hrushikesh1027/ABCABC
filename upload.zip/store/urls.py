from django.contrib import admin
from django.urls import path
from store.views import *

urlpatterns = [
    path('',home,name='homepage'),
    path('cart/',cart),
    path('orders/',orders),
    path('login/',login),
    path('signup/',signup),
    path('logout/',signout),
    path('item/<int:id>',show_item)
]